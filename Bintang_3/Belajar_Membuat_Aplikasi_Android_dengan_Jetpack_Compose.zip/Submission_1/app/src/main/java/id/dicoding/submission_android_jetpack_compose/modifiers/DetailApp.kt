package id.dicoding.submission_android_jetpack_compose.modifiers

import android.annotation.SuppressLint
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import coil.compose.AsyncImage
import id.dicoding.submission_android_jetpack_compose.model.ListsData
import id.dicoding.submission_android_jetpack_compose.model.ListTV

@SuppressLint("UnusedMaterialScaffoldPaddingParameter")
@Composable
fun DetailScreen(listId: String, navController: NavController, modifier: Modifier) {
    fun getItem(itemId: String): ListTV? = ListsData.lists.find {
        it.id == itemId
    }
    val item: ListTV? = remember(listId) { getItem(listId) }
    Scaffold(
        topBar = {
            TopAppBar(elevation = 10.dp) {
                Button(onClick = {navController.popBackStack()}) {
                    Icon(
                        Icons.Filled.ArrowBack,
                        contentDescription = "Kembali",
                        modifier = Modifier.size(20.dp)
                    )
                }
                Spacer(modifier = Modifier.width(10.dp))
                if (item != null) {
                    Text(text = item.name, fontSize = 28.sp, fontWeight = FontWeight.Bold)
                }
            }
        }
    ) {
        Column(
            modifier = modifier.fillMaxSize().verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            if (item != null) {
                AsyncImage(
                    model = item.photoUrl,
                    contentDescription = "Translated description of what the image contains",
                    modifier = Modifier.size(128.dp)
                )
                Text(text = item.name, fontSize = 21.sp, fontWeight = FontWeight.Bold)
                Text(text = item.description, fontSize = 18.sp, fontWeight = FontWeight.Normal)
            }
        }
    }
}