package id.dicoding.submission_android_jetpack_compose.navigation

sealed class Screen(val route: String) {
    object Home : Screen("home")
    object Profile : Screen("profile")
    object Detail : Screen("home/{detailId}") {
        fun createRoute(detailId: String) = "home/$detailId"
    }
}