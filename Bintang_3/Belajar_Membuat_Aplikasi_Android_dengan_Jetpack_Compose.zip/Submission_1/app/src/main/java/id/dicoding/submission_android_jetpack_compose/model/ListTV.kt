package id.dicoding.submission_android_jetpack_compose.model

data class ListTV(
    val id: String,
    val name: String,
    val photoUrl: String,
    val description: String
)