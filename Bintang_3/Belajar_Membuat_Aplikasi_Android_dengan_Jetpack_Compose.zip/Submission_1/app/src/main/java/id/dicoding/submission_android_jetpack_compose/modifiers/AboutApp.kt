package id.dicoding.submission_android_jetpack_compose.modifiers

import android.annotation.SuppressLint
import androidx.compose.foundation.layout.*
import androidx.compose.material.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavHostController
import androidx.navigation.compose.rememberNavController
import coil.compose.AsyncImage
import id.dicoding.submission_android_jetpack_compose.ui.theme.Submission_android_jetpack_composeTheme

@SuppressLint("UnusedMaterialScaffoldPaddingParameter")
@Composable
fun AboutApp(modifier: Modifier, navController: NavHostController) {
    Scaffold(
        topBar = {
            TopAppBar(elevation = 10.dp) {
                Button(onClick = {navController.popBackStack()}) {
                    Icon(
                        Icons.Filled.ArrowBack,
                        contentDescription = "Kembali",
                        modifier = Modifier.size(20.dp)
                    )
                }
                Spacer(modifier = Modifier.width(10.dp))
                Text(text = "Profil Saya", fontSize = 28.sp, fontWeight = FontWeight.Bold)
            }
        }
    ) {
        Box(modifier = modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
            Column(
                modifier = modifier
                    .fillMaxSize()
                    .fillMaxWidth()
                    .fillMaxHeight()
                    .padding(10.dp),
                verticalArrangement = Arrangement.Center,
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                AsyncImage(
                    model = "https://avatars.githubusercontent.com/u/61810752?v=4",
                    contentDescription = "Translated description of what the image contains",
                    modifier = Modifier.size(128.dp)
                )
                Text(text = "Wilson Jonathan Oey", fontSize = 21.sp, fontWeight = FontWeight.Bold)
                Text(text = "wilsonoey60@gmail.com", fontSize = 21.sp, fontWeight = FontWeight.Normal)
            }
        }
    }
}

@Preview(showBackground = true)
@Composable
fun AboutAppPreview() {
    Submission_android_jetpack_composeTheme {
        AboutApp(modifier = Modifier, navController = rememberNavController())
    }
}