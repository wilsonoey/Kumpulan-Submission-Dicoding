package id.dicoding.fundamentalandroid2023.Api

data class ApiStructure (
    val total_count: Int,
    val incomplete_results: Boolean,
    val items: List<ApiItemStructure>
)

data class ApiItemStructure(
    val login: String? = null,
    val avatar_url: String? = null,
    val url: String? = null,
    val followers: Int? = null,
    val following: Int? = null,
    val name: String? = null,
    val following_url: String? = null,
    val followers_url: String? = null,
    val location: String? = null,
)