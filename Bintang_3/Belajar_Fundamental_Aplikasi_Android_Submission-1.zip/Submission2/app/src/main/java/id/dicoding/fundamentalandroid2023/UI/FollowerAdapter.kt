package id.dicoding.fundamentalandroid2023.UI

import android.view.LayoutInflater
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import id.dicoding.fundamentalandroid2023.Api.ApiItemStructure
import id.dicoding.fundamentalandroid2023.databinding.ActivityMainBinding
import id.dicoding.fundamentalandroid2023.databinding.ListItemBinding

class FollowerAdapter(private val followerDataList: List<ApiItemStructure>) : RecyclerView.Adapter<FollowerAdapter.FollowerViewHolder>() {
    private var binding: ActivityMainBinding? = null
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): FollowerViewHolder {
        val view = ListItemBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return FollowerViewHolder(view)
    }

    override fun getItemCount() = followerDataList.size

    override fun onBindViewHolder(holder: FollowerViewHolder, position: Int) {
        with(holder){
            binding.apply {
                val followerData = followerDataList[position]
                Glide.with(itemView.context).load(followerData.avatar_url).into(avatarImageView)
                nameTextView.text = followerData.login
                urlTextView.text = followerData.url
            }
        }
    }

    inner class FollowerViewHolder(val binding: ListItemBinding) : RecyclerView.ViewHolder(binding.root) {
        val avatarImageView: ImageView = binding.avatar
        val nameTextView: TextView = binding.name
        val urlTextView: TextView = binding.url
    }
}