package id.dicoding.fundamentalandroid2023

import android.app.SearchManager
import android.content.Context
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.widget.ProgressBar
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import id.dicoding.fundamentalandroid2023.Api.ApiClient
import id.dicoding.fundamentalandroid2023.Api.ApiInterface
import id.dicoding.fundamentalandroid2023.Api.ApiItemStructure
import id.dicoding.fundamentalandroid2023.Api.ApiStructure
import id.dicoding.fundamentalandroid2023.UI.ListAdapter
import okhttp3.OkHttpClient
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import androidx.appcompat.widget.SearchView

class MainActivity : AppCompatActivity() {
    private lateinit var recyclerView: RecyclerView
    private lateinit var apiInterface: ApiInterface
    private lateinit var listAdapter: ListAdapter
    private lateinit var loadingView: ProgressBar
    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        val inflater = menuInflater
        inflater.inflate(R.menu.home, menu)

        val searchManager = getSystemService(Context.SEARCH_SERVICE) as SearchManager
        val searchView = menu.findItem(R.id.search).actionView as SearchView

        searchView.setSearchableInfo(searchManager.getSearchableInfo(componentName))
        searchView.queryHint = resources.getString(R.string.queryhint)
        searchView.setOnQueryTextListener(object : SearchView.OnQueryTextListener {
            override fun onQueryTextSubmit(query: String): Boolean {
                searchUser(query)
                return false
            }

            override fun onQueryTextChange(query: String): Boolean {
                return false
            }
        })
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when (item.itemId) {
            R.id.search -> {
                super.onOptionsItemSelected(item)
            }
            else -> true
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        val apiClient = ApiClient(OkHttpClient())
        apiInterface = apiClient.getClient()
        loadingView = findViewById(R.id.loading)
        recyclerView = findViewById(R.id.recycler_view)
        loadingView.visibility = View.VISIBLE
        getUsersList()
    }
    private fun getUsersList() {
        val call = apiInterface.getUsersList()
        call.enqueue(object : Callback<List<ApiItemStructure>> {
            override fun onResponse(
                call: Call<List<ApiItemStructure>>,
                response: Response<List<ApiItemStructure>>
            ) {
                loadingView.visibility = View.GONE
                if (response.isSuccessful) {
                    val userDataList = response.body()
                    listAdapter = ListAdapter(userDataList!!)
                    recyclerView.layoutManager = LinearLayoutManager(applicationContext)
                    recyclerView.adapter = listAdapter
                }
            }
            override fun onFailure(call: Call<List<ApiItemStructure>>, t: Throwable) {
            }
        })
    }

    private fun searchUser(query: String) {
        loadingView.visibility = View.VISIBLE
        apiInterface.searchUser(query).enqueue(object : Callback<ApiStructure> {
            override fun onResponse(call: Call<ApiStructure>, response: Response<ApiStructure>) {
                loadingView.visibility = View.GONE
                if (response.isSuccessful) {
                    listAdapter = ListAdapter(response.body()!!.items)
                    recyclerView.adapter = listAdapter
                }
            }

            override fun onFailure(call: Call<ApiStructure>, t: Throwable) {
                Toast.makeText(applicationContext, t.message, Toast.LENGTH_SHORT).show()
            }
        })
    }
}
