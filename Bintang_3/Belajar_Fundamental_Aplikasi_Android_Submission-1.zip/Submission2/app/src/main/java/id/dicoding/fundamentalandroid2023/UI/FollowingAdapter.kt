package id.dicoding.fundamentalandroid2023.UI

import android.view.LayoutInflater
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import id.dicoding.fundamentalandroid2023.Api.ApiItemStructure
import id.dicoding.fundamentalandroid2023.databinding.ActivityMainBinding
import id.dicoding.fundamentalandroid2023.databinding.ListItemBinding

class FollowingAdapter(private val followingDataList: List<ApiItemStructure>) : RecyclerView.Adapter<FollowingAdapter.FollowingViewHolder>() {
    private var binding: ActivityMainBinding? = null
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): FollowingViewHolder {
        val view = ListItemBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return FollowingViewHolder(view)
    }

    override fun getItemCount() = followingDataList.size

    override fun onBindViewHolder(holder: FollowingViewHolder, position: Int) {
        with(holder){
            binding.apply {
                val followingData = followingDataList[position]
                Glide.with(itemView.context).load(followingData.avatar_url).into(avatarImageView)
                nameTextView.text = followingData.login
                urlTextView.text = followingData.url
            }
        }
    }

    inner class FollowingViewHolder(itemView: ListItemBinding) : RecyclerView.ViewHolder(itemView.root) {
        val avatarImageView: ImageView = itemView.avatar
        val nameTextView: TextView = itemView.name
        val urlTextView: TextView = itemView.url
    }
}