package id.dicoding.fundamentalandroid2023.api

data class ApiStructure (
    val items: List<ApiItemStructure>
)

data class ApiItemStructure(
    val id: Int = 0,
    val login: String? = null,
    val avatar_url: String? = null,
    val url: String? = null,
    val followers: Int? = null,
    val following: Int? = null,
    val name: String? = null,
    val location: String? = null,
)