package id.dicoding.fundamentalandroid2023.api

import id.dicoding.fundamentalandroid2023.BuildConfig
import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory

class ApiClient {
    fun getClient(): ApiInterface {
        val okHttpClient = OkHttpClient.Builder().addInterceptor { chain ->
            val original = chain.request()
            val apiKey = BuildConfig.KEY
            val request = original.newBuilder()
                .header("Authorization", "token $apiKey")
                .method(original.method, original.body)
                .build()
            chain.proceed(request)
        }.apply {
            if (BuildConfig.DEBUG) {
                val logging = HttpLoggingInterceptor()
                logging.setLevel(HttpLoggingInterceptor.Level.BODY)
                addInterceptor(logging)
            }
        }.build()
        val retrofit = Retrofit.Builder()
            .baseUrl(BuildConfig.API)
            .addConverterFactory(GsonConverterFactory.create())
            .client(okHttpClient)
            .build()
        return retrofit.create(ApiInterface::class.java)
    }
}