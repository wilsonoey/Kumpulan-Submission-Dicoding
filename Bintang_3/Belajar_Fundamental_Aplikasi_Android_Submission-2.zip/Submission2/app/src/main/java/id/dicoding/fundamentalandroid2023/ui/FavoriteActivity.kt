package id.dicoding.fundamentalandroid2023.ui

import android.os.Bundle
import android.view.View
import android.widget.ProgressBar
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import id.dicoding.fundamentalandroid2023.favorite.FavoriteUserDao
import id.dicoding.fundamentalandroid2023.favorite.UserDatabase
import id.dicoding.fundamentalandroid2023.databinding.FavoriteBinding
import kotlinx.coroutines.*

class FavoriteActivity : AppCompatActivity() {
    private lateinit var loadingView: ProgressBar
    private var userDao: FavoriteUserDao? = null
    private var userDatabase: UserDatabase? = null
    private lateinit var binding: FavoriteBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = FavoriteBinding.inflate(layoutInflater)
        setContentView(binding.root)
        println("My data is $userDao and $userDatabase")
        loadingView = binding.loadingFavorite // Initialize the loadingView property
        userDatabase = UserDatabase.getInstance(this)
        userDao = userDatabase?.favoriteUserDao()
        CoroutineScope(Dispatchers.Main).launch {
            val favoriteUser = withContext(Dispatchers.IO) {
                userDao?.getFavoriteUser()
            }
            if (favoriteUser != null) {
                val adapter = FavoriteAdapter(favoriteUser)
                binding.favoriteRecyclerView.layoutManager = LinearLayoutManager(this@FavoriteActivity)
                binding.favoriteRecyclerView.adapter = adapter
                loadingView.visibility = View.GONE
            }
        }
    }
}