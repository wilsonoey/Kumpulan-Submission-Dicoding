package id.dicoding.fundamentalandroid2023.ui

import android.content.Intent
import android.view.LayoutInflater
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import id.dicoding.fundamentalandroid2023.api.ApiItemStructure
import id.dicoding.fundamentalandroid2023.databinding.ListItemBinding

class ListAdapter(private val followingDataList: List<ApiItemStructure>) : RecyclerView.Adapter<ListAdapter.FollowingViewHolder>() {
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): FollowingViewHolder {
        val view = ListItemBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return FollowingViewHolder(view)
    }

    override fun getItemCount() = followingDataList.size

    override fun onBindViewHolder(holder: FollowingViewHolder, position: Int) {
        with(holder){
            binding.apply {
                val followingData = followingDataList[position]
                Glide.with(itemView.context).load(followingData.avatar_url).into(avatarImageView)
                nameTextView.text = followingData.login
                urlTextView.text = followingData.url
                holder.itemView.setOnClickListener{
                    val intentDetail = Intent(holder.itemView.context, DetailActivity::class.java)
                    intentDetail.putExtra(DetailActivity.EXTRA_USER, followingData.login)
                    holder.itemView.context.startActivity(intentDetail)
                }
            }
        }
    }

    inner class FollowingViewHolder(val binding: ListItemBinding) : RecyclerView.ViewHolder(binding.root) {
        val avatarImageView: ImageView = binding.avatar
        val nameTextView: TextView = binding.name
        val urlTextView: TextView = binding.url
    }
}