package id.dicoding.fundamentalandroid2023.ui

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ProgressBar
import android.widget.Toast
import androidx.core.os.bundleOf
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import id.dicoding.fundamentalandroid2023.api.ApiClient
import id.dicoding.fundamentalandroid2023.api.ApiItemStructure
import id.dicoding.fundamentalandroid2023.R
import id.dicoding.fundamentalandroid2023.databinding.FragmentBinding
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class FollowingFragment : Fragment() {

    companion object {
        private const val USERNAME = "username"
        fun newInstance(username: String): FollowingFragment {
            return FollowingFragment().apply {
                arguments = bundleOf(USERNAME to username)
            }
        }
    }

    private lateinit var apiClient: ApiClient
    private lateinit var followingRecyclerView: RecyclerView
    private lateinit var loadingView: ProgressBar
    private lateinit var binding: FragmentBinding

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        return inflater.inflate(R.layout.fragment, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        binding = FragmentBinding.bind(view)
        followingRecyclerView = binding.fragmentRecyclerView
        loadingView = binding.loadingFragment
        followingRecyclerView.layoutManager = LinearLayoutManager(view.context)
        loadingView.visibility = View.VISIBLE
        apiClient = ApiClient()
        getFollowing(arguments?.getString(USERNAME)!!)
    }

    private fun getFollowing(username: String?) {
        apiClient.getClient().getFollowing(username!!).enqueue(object : Callback<List<ApiItemStructure>> {
            override fun onResponse(call: Call<List<ApiItemStructure>>, response: Response<List<ApiItemStructure>>) {
                loadingView.visibility = View.GONE
                if (response.isSuccessful) {
                    val followingDataList = response.body()
                    followingRecyclerView.adapter = ListAdapter(followingDataList!!)
                }
            }

            override fun onFailure(call: Call<List<ApiItemStructure>>, t: Throwable) {
                loadingView.visibility = View.GONE
                Toast.makeText(context, "Error Fetching Data", Toast.LENGTH_SHORT).show()
            }
        })
    }
}