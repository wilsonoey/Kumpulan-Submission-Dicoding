package id.dicoding.fundamentalandroid2023

import android.app.SearchManager
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.widget.CompoundButton
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.app.AppCompatDelegate
import androidx.recyclerview.widget.LinearLayoutManager
import id.dicoding.fundamentalandroid2023.api.ApiClient
import id.dicoding.fundamentalandroid2023.api.ApiInterface
import id.dicoding.fundamentalandroid2023.api.ApiItemStructure
import id.dicoding.fundamentalandroid2023.api.ApiStructure
import id.dicoding.fundamentalandroid2023.ui.ListAdapter
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import androidx.appcompat.widget.SearchView
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.preferencesDataStore
import androidx.lifecycle.ViewModelProvider
import id.dicoding.fundamentalandroid2023.preferences.SettingPreferences
import id.dicoding.fundamentalandroid2023.ui.FavoriteActivity
import id.dicoding.fundamentalandroid2023.viewModel.MainViewModel
import id.dicoding.fundamentalandroid2023.viewModel.ViewModelFactory
import id.dicoding.fundamentalandroid2023.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMainBinding
    private lateinit var apiInterface: ApiInterface
    private lateinit var listAdapter: ListAdapter
    private val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "settings")

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menuInflater.inflate(R.menu.home, menu)

        val searchManager = getSystemService(Context.SEARCH_SERVICE) as SearchManager
        val searchView = menu.findItem(R.id.search).actionView as SearchView

        searchView.setSearchableInfo(searchManager.getSearchableInfo(componentName))
        searchView.queryHint = resources.getString(R.string.queryhint)
        searchView.setOnQueryTextListener(object : SearchView.OnQueryTextListener {
            override fun onQueryTextSubmit(query: String): Boolean {
                searchUser(query)
                return false
            }

            override fun onQueryTextChange(query: String): Boolean {
                return false
            }
        })

        if (searchView.query.isEmpty()) {
            binding.loading.visibility = View.GONE
            getUsersList()
        }

        searchView.setOnQueryTextFocusChangeListener { _, hasFocus ->
            if (!hasFocus) {
                binding.loading.visibility = View.GONE
                getUsersList()
            }
        }
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when (item.itemId) {
            R.id.search -> {
                super.onOptionsItemSelected(item)
            }
            R.id.favorite -> {
                val i = Intent(this, FavoriteActivity::class.java)
                startActivity(i)
                true
            }
            else -> true
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        val apiClient = ApiClient()
        apiInterface = apiClient.getClient()
        binding.loading.visibility = View.VISIBLE
        getUsersList()
        val switchTheme = binding.switchTheme

        val pref = SettingPreferences.getInstance(dataStore)
        val mainViewModel = ViewModelProvider(this, ViewModelFactory(pref))[MainViewModel::class.java]
        mainViewModel.getThemeSettings().observe(this) { isDarkModeActive: Boolean ->
            if (isDarkModeActive) {
                AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES)
                switchTheme.isChecked = true
            } else {
                AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO)
                switchTheme.isChecked = false
            }
        }

        switchTheme.setOnCheckedChangeListener { _: CompoundButton?, isChecked: Boolean ->
            mainViewModel.saveThemeSetting(isChecked)
        }
    }

    private fun getUsersList() {
        apiInterface.getUsersList().enqueue(object : Callback<List<ApiItemStructure>> {
            override fun onResponse(
                call: Call<List<ApiItemStructure>>,
                response: Response<List<ApiItemStructure>>
            ) {
                binding.loading.visibility = View.GONE
                if (response.isSuccessful) {
                    val userDataList = response.body()
                    listAdapter = ListAdapter(userDataList!!)
                    binding.recyclerView.layoutManager = LinearLayoutManager(applicationContext)
                    binding.recyclerView.adapter = listAdapter
                }
            }

            override fun onFailure(call: Call<List<ApiItemStructure>>, t: Throwable) {
                binding.loading.visibility = View.GONE
                Toast.makeText(applicationContext, t.message, Toast.LENGTH_SHORT).show()
            }
        })
    }

    private fun searchUser(query: String) {
        binding.loading.visibility = View.VISIBLE
        apiInterface.searchUser(query).enqueue(object : Callback<ApiStructure> {
            override fun onResponse(call: Call<ApiStructure>, response: Response<ApiStructure>) {
                binding.loading.visibility = View.GONE
                if (response.isSuccessful) {
                    listAdapter = ListAdapter(response.body()!!.items)
                    binding.recyclerView.layoutManager = LinearLayoutManager(applicationContext)
                    binding.recyclerView.adapter = listAdapter
                }
            }

            override fun onFailure(call: Call<ApiStructure>, t: Throwable) {
                binding.loading.visibility = View.GONE
                Toast.makeText(applicationContext, t.message, Toast.LENGTH_SHORT).show()
            }
        })
    }
}
