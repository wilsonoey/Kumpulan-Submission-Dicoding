package id.dicoding.fundamentalandroid2023.ui

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.ImageView
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.annotation.StringRes
import com.bumptech.glide.Glide
import com.google.android.material.tabs.TabLayoutMediator
import id.dicoding.fundamentalandroid2023.api.ApiClient
import id.dicoding.fundamentalandroid2023.api.ApiItemStructure
import id.dicoding.fundamentalandroid2023.favorite.FavoriteUser
import id.dicoding.fundamentalandroid2023.favorite.UserDatabase
import id.dicoding.fundamentalandroid2023.R
import kotlinx.coroutines.*
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import id.dicoding.fundamentalandroid2023.databinding.ActivityDetailBinding

class DetailActivity : AppCompatActivity() {
    private lateinit var apiClient: ApiClient
    private lateinit var fullNameTextView: TextView
    private lateinit var usernameTextView: TextView
    private lateinit var followingCountTextView: TextView
    private lateinit var followersCountTextView: TextView
    private lateinit var profilePictureImageView: ImageView
    private lateinit var favoriteItemButtonView: ImageView
    private lateinit var loadingView: ProgressBar
    private lateinit var detaillocationTextView: TextView
    private lateinit var binding: ActivityDetailBinding

    companion object {
        const val EXTRA_USER = "extra_user"
        @StringRes
        private val TAB_TITLES = intArrayOf(
            R.string.tab_followers,
            R.string.tab_following
        )
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityDetailBinding.inflate(layoutInflater)
        setContentView(binding.root)
        loadingView = binding.loadingDetail
        fullNameTextView = binding.detailname
        usernameTextView = binding.detailusername
        followingCountTextView = binding.detailfollowingcount
        followersCountTextView = binding.detailfollowerscount
        profilePictureImageView = binding.detailimage
        detaillocationTextView = binding.detaillocation
        favoriteItemButtonView = binding.favoriteitembutton
        val username = intent.getStringExtra(EXTRA_USER)
        apiClient = ApiClient()
        getDetail(username)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        supportActionBar?.title = username
    }

    private fun getDetail(username: String?) {
        apiClient.getClient().getDetail(username!!).enqueue(object : Callback<ApiItemStructure> {
            override fun onResponse(call: Call<ApiItemStructure>, response: Response<ApiItemStructure>) {
                loadingView.visibility = View.GONE
                if(response.isSuccessful) {
                    val userData = response.body()
                    fullNameTextView.text = userData?.name
                    usernameTextView.text = userData?.login
                    followingCountTextView.text = StringBuilder(userData?.following.toString() + "\n" +
                            "Following")
                    followersCountTextView.text = StringBuilder(userData?.followers.toString() + "\n" +
                            "Followers")
                    Glide.with(this@DetailActivity).load(userData?.avatar_url).into(profilePictureImageView)
                    detaillocationTextView.text = userData?.location
                    val sectionsPagerAdapter = FragmentsAdapter(this@DetailActivity, userData?.login!!)
                    val viewpager = binding.viewPager
                    viewpager.adapter = sectionsPagerAdapter
                    TabLayoutMediator(binding.tabs, viewpager) { tab, position ->
                        tab.text = resources.getString(TAB_TITLES[position])
                    }.attach()
                    val user = userData.let {
                        FavoriteUser(
                            it.id,
                            it.login,
                            it.avatar_url,
                            it.url
                        )
                    }
                    checkFavorite(user)
                    supportActionBar?.elevation = 0f
                }

            }
            override fun onFailure(call: Call<ApiItemStructure>, t: Throwable) {
                loadingView.visibility = View.GONE
                Toast.makeText(this@DetailActivity, "Failed to get data", Toast.LENGTH_SHORT).show()
            }
        })
    }

    private fun checkFavorite(user: FavoriteUser) {
        CoroutineScope(Dispatchers.IO).launch {
            val db = UserDatabase.getInstance(this@DetailActivity)
            val isFavorite = db?.favoriteUserDao()?.isFavorite(user.id)
            if (isFavorite == 0) {
                favoriteItemButtonView.setImageResource(R.drawable.ic_baseline_favorite_border_24)
            } else {
                favoriteItemButtonView.setImageResource(R.drawable.ic_baseline_favorite_24)
            }
        }
        favoriteItemButtonView.setOnClickListener {
            CoroutineScope(Dispatchers.IO).launch {
                val db = UserDatabase.getInstance(this@DetailActivity)
                if (db?.favoriteUserDao()?.isFavorite(user.id) == 0) {
                    db.favoriteUserDao().insertFavoriteUser(user)
                    favoriteItemButtonView.setImageResource(R.drawable.ic_baseline_favorite_24)
                } else {
                    db?.favoriteUserDao()?.deleteFavoriteUser(user.id)
                    favoriteItemButtonView.setImageResource(R.drawable.ic_baseline_favorite_border_24)
                }
            }
        }
    }    
}